"""Build Finder launchers from the source bundle. Run from ROOT."""
from pathlib import Path
import os
import plistlib
import shlex
import shutil
import subprocess

root = Path.cwd()
prefix = Path(os.environ['MP'])
apps = root/'apps'
apps.mkdir(exist_ok=True)
cfile = root/'launcher.c'
cfile.write_text(r'''
#include <stdio.h>
#include <unistd.h>
int main(int argc, char **argv)
{
    (void)argc;
    argv[0] = LAUNCH_SCRIPT;
    execv(LAUNCH_SCRIPT, argv);
    perror(LAUNCH_SCRIPT);
    return 126;
}
''')
for name, slug, tool in [('Athena','athena',''), ('Artemis','artemis','Artemis'),
                          ('Hephaestus','hephaestus','Hephaestus'),
                          ('Stand-alone Atoms','atoms','Atoms')]:
    app = apps/f'{name}.app'
    contents = app/'Contents'
    resources = contents/'Resources'
    resources.mkdir(parents=True, exist_ok=True)
    macos = contents/'MacOS'
    macos.mkdir(exist_ok=True)
    shutil.copyfile(root/'icons'/f'{name}.icns', resources/'App.icns')
    script = resources/'launch.sh'
    command = [str(prefix/'bin/perl5.34')]
    command += [str(root/'demeter-desktop'),tool] if tool else [str(root/'dathena-nosplash')]
    state = root/'state'/slug
    state.mkdir(parents=True, exist_ok=True)
    config_file = state/'demeter.ini'
    if not config_file.exists():
        config_file.write_text('[gnuplot]\nprogram = gnuplot\nterminal = wxt\nbg = white\n')
    appearance = state/'appearance'
    if not appearance.exists():
        appearance.write_text('light\n')
    logs = root/'logs' 
    logs.mkdir(exist_ok=True)
    config = [
        '#!/bin/sh', 'set -eu',
        f'export PATH={shlex.quote(str(prefix/"bin"))}:"$PATH"',
        f'export ATHENA_CONFIG_DIR={shlex.quote(str(state))}',
        'export PERL5LIB='+shlex.quote(f'{root}/overlay:{root}/extra/lib/perl5'),
    ]
    if not tool:
        config.append('export PATH='+shlex.quote(str(root/'plot-fix/bin'))+':"$PATH"')
    if tool and (root/'wx-fixed/libwx_osx_cocoau_core-3.0.dylib').exists():
        config.append('export DYLD_LIBRARY_PATH='+shlex.quote(str(root/'wx-fixed')))
    config.append('cd '+shlex.quote(str(root)))
    config.append(f'exec {shlex.join(command)} "$@" >> {shlex.quote(str(logs/slug))}.log 2>&1')
    # The script stays inside the installed bundle. The compiled entry point
    # derives its path so moving the bundle to Applications keeps it usable.
    script.write_text('\n'.join(config)+'\n')
    script.chmod(0o755)
    source = cfile.read_text()
    source = source.replace('#include <unistd.h>', '#include <unistd.h>\n'
                            '#include <mach-o/dyld.h>\n#include <limits.h>\n#include <string.h>')
    source = source.replace('    argv[0] = LAUNCH_SCRIPT;', '''    char launch[PATH_MAX];
    uint32_t len = sizeof(launch);
    if (_NSGetExecutablePath(launch, &len) != 0) return 126;
    char *base = strrchr(launch, '/');
    if (!base) return 126;
    *base = '\\0';
    const char suffix[] = "/../Resources/launch.sh";
    if (strlen(launch) + sizeof(suffix) > sizeof(launch)) return 126;
    strcat(launch, suffix);
    argv[0] = launch;''').replace('LAUNCH_SCRIPT', 'launch')
    cfile.write_text(source)
    subprocess.run(['xcrun','clang','-Wall','-Wextra','-Werror',cfile,'-o',macos/slug],check=True)
    cfile.write_text(r'''
#include <stdio.h>
#include <unistd.h>
int main(int argc, char **argv)
{
    (void)argc;
    argv[0] = LAUNCH_SCRIPT;
    execv(LAUNCH_SCRIPT, argv);
    perror(LAUNCH_SCRIPT);
    return 126;
}
''')
    with (contents/'Info.plist').open('wb') as f:
        plistlib.dump(dict(CFBundleExecutable=slug, CFBundleName=name,
                            CFBundleIdentifier=f'local.demeter.guide.{slug}',
                            CFBundlePackageType='APPL', CFBundleIconFile='App.icns'), f)
    subprocess.run(['codesign','--force','--sign','-',app],check=True)
    subprocess.run(['codesign','--verify','--strict',app],check=True)
cfile.unlink()
