#import <AppKit/AppKit.h>
#include "EXTERN.h"
#include "perl.h"
#include "XSUB.h"

XS(athena_set_appearance) {
    dXSARGS;
    if (items != 1) croak("Expected an Athena appearance");
    @autoreleasepool {
        NSAppearanceName name = SvTRUE(ST(0)) ? NSAppearanceNameDarkAqua : NSAppearanceNameAqua;
        NSApplication *app = [NSApplication sharedApplication];
        app.appearance = [NSAppearance appearanceNamed:name];
    }
    XSRETURN_EMPTY;
}
