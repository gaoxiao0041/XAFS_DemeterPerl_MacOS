Compatibility sources for the Demeter macOS 27.2 online installer v2.
No personal settings, user data or prebuilt runtime are included.
See README.md and THIRD_PARTY_NOTICES.md in the release.
