"""Fix the old Cocoa shading callback lifetime. Run from ROOT."""
from pathlib import Path
import os
import shutil
import subprocess

root = Path.cwd()
prefix = Path(os.environ['MP'])
if os.geteuid() == 0:
    raise SystemExit('Run this in the writable private prefix, without sudo.')
sources = list(prefix.glob('var/macports/build/wxWidgets-3.0-*/work/wx*/src/osx/carbon/graphics.cpp'))
if len(sources) != 1:
    raise SystemExit('Expected one retained wxWidgets 3.0 build tree.')
source = sources[0]
backup = source.with_suffix('.cpp.original')
if not backup.exists():
    shutil.copy2(source, backup)
s = backup.read_text()
edits = {
    '    GradientComponents m_gradientComponents;':
        '    static void ReleaseGradientComponents(void *info)\n'
        '    {\n        delete static_cast<GradientComponents*>(info);\n    }',
    '0, &CalculateShadingValues, NULL':
        '0, &CalculateShadingValues, &ReleaseGradientComponents',
    '    m_gradientComponents.Init(stops.GetCount());':
        '    GradientComponents* components = new GradientComponents;\n'
        '    components->Init(stops.GetCount());',
    'm_gradientComponents.count': 'components->count',
    'm_gradientComponents.comps': 'components->comps',
    'return CGFunctionCreate ( &m_gradientComponents,': 'return CGFunctionCreate ( components,',
}
for old, new in edits.items():
    if old not in s:
        raise SystemExit(f'Unexpected source version: {old}')
    s = s.replace(old, new)
source.write_text(s)
build = source.parents[3] / 'build'
subprocess.run(['make','-j8'], cwd=build, check=True)
fw = prefix/'Library/Frameworks/wxWidgets.framework/Versions/wxWidgets/3.0/lib'
out = root/'wx-fixed'
out.mkdir(exist_ok=True)
name = 'libwx_osx_cocoau_core-3.0.dylib'
dst = out/name
shutil.copyfile(build/'lib/libwx_osx_cocoau_core-3.0.0.5.0.dylib', dst)
dst.chmod(0o755)
subprocess.run(['install_name_tool','-id',str(fw/name),dst], check=True)
for line in subprocess.check_output(['otool','-L',dst],text=True).splitlines()[1:]:
    dep = line.strip().split(' (',1)[0]
    if '/build/' in dep and '/libwx_' in dep:
        subprocess.run(['install_name_tool','-change',dep,str(fw/Path(dep).name),dst],check=True)
subprocess.run(['codesign','--force','--sign','-',dst],check=True)
for version in ('3.0.0','3.0.0.5.0'):
    alias = out/f'libwx_osx_cocoau_core-{version}.dylib'
    alias.unlink(missing_ok=True)
    alias.symlink_to(name)
