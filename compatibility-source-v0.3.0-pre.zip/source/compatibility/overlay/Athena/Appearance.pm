package Athena::Appearance;
use utf8;
use strict;
use warnings;
use DynaLoader ();
use File::Basename qw(dirname);
use Wx::Event qw(EVT_MENU);

my $library = DynaLoader::dl_load_file(dirname(__FILE__) . '/Appearance.bundle', 0)
    or die DynaLoader::dl_error();
my $symbol = DynaLoader::dl_find_symbol($library, 'athena_set_appearance')
    or die DynaLoader::dl_error();
DynaLoader::dl_install_xsub(__PACKAGE__ . '::set_native', $symbol, __FILE__);

my $preference = "$ENV{ATHENA_CONFIG_DIR}/appearance";
my $dark = 0;
if (open my $input, '<', $preference) {
    my $value = <$input> // '';
    $dark = $value =~ /\Adark\s*\z/ ? 1 : 0;
}

sub prepare { set_native(0) }

my %original;
my %label_roles;
my %label_palette = (
    normal  => ['#202124', '#F0F1F4'],
    frozen  => ['#006A65', '#86DED4'],
    warning => ['#B42318', '#FFA49B'],
);

sub set_label_role {
    my ($label, $role) = @_;
    $label_roles{$label->GetId} = $role;
    $label->SetForegroundColour(Wx::Colour->new($label_palette{$role}[$dark]));
}

sub capture {
    my ($window) = @_;
    return unless $window->isa("Wx::Window");
    my $key = $window->GetId;
    my $color = $window->GetBackgroundColour;
    $original{$key} = $color->IsOk
        ? Wx::Colour->new($color->Red, $color->Green, $color->Blue) : $color;
    capture($_) for $window->GetChildren;
}

sub recolor {
    my ($window) = @_;
    return unless $window->isa("Wx::Window");
    my $bg = $original{$window->GetId} || $window->GetBackgroundColour;
    if ($dark) {
        my $accent = $bg->Red > 225 && $bg->Green < 230;
        my $field = $window->isa('Wx::TextCtrl') || $window->isa('Wx::ComboBox')
                    || $window->isa('Wx::ListBox');
        my $surface = $accent ? ($bg->Blue > 205 ? '#563B67' : '#62491F')
                    : $field ? '#34363B' : '#292B30';
        $window->SetBackgroundColour(Wx::Colour->new($surface));
    } else {
        $window->SetBackgroundColour($bg);
    }
    my $role = $label_roles{$window->GetId} // 'normal';
    $window->SetForegroundColour(Wx::Colour->new($label_palette{$role}[$dark]));
    recolor($_) for $window->GetChildren;
    $window->Refresh;
}

sub apply {
    my ($frame) = @_;
    set_native($dark);
    recolor($frame);
}

sub add_menu {
    my ($frame) = @_;
    my $menu = Wx::Menu->new;
    my @ids = map { Wx::NewId() } 1..2;
    $menu->AppendRadioItem($ids[0], 'Light');
    $menu->AppendRadioItem($ids[1], 'Dark');
    $menu->Check($ids[$dark], 1);
    for my $mode (0, 1) {
        EVT_MENU($frame, $ids[$mode], sub {
            capture($frame) if !$dark && $mode;
            $dark = $mode;
            apply($frame);
            if (open my $output, '>', $preference) {
                print {$output} ($dark ? "dark\n" : "light\n");
                close $output;
            }
        });
    }
    $frame->GetMenuBar->Append($menu, 'Appearance');
    capture($frame);
    apply($frame);
}

1;
