package Athena::PlotMenu;
use strict;
use warnings;
use File::Temp ();
use Encode qw(encode_utf8);
use Wx ();
use Wx::Event ();

my $directory;
sub prepare {
    $directory ||= File::Temp->newdir('athena-menu-XXXXXXXX', TMPDIR => 1, CLEANUP => 1);
    $ENV{ATHENA_MENU_BRIDGE} = "$directory";
}

sub start {
    my ($app) = @_;
    prepare();
    my $dir = $directory;
    $app->{plot_menu_dir} = $dir;
    $ENV{ATHENA_MENU_BRIDGE} = "$dir";
    my $timer = Wx::Timer->new($app->{main});
    $app->{plot_menu_timer} = $timer;
    my $last = '';
    my %allowed;
    our $updating = 0;
    Wx::Event::EVT_TIMER($app->{main}, $timer->GetId, sub {
        return if $updating;
        local $updating = 1;
        my $bar = $app->{main}->GetMenuBar;
        return unless $bar;
        my @rows;
        my %current;
        my $walk;
        $walk = sub {
            my ($menu, $depth) = @_;
            for my $item ($menu->GetMenuItems) {
                my $label = $item->GetItemLabel;
                $label =~ s/[\t\r\n]/ /g;
                my $sub = $item->GetSubMenu;
                my $type = $item->IsSeparator ? 'S' : $sub ? 'M' : 'I';
                my $id = $item->GetId;
                push @rows, join("\t", $depth, $type, $id, $item->IsEnabled ? 1 : 0,
                    $item->IsCheckable ? ($item->IsChecked ? 2 : 1) : 0, $label);
                $current{$id} = $item if $type eq 'I';
                $walk->($sub, $depth+1) if $sub;
            }
        };
        for my $n (0 .. $bar->GetMenuCount-1) {
            my $label = $bar->GetMenuLabel($n);
            $label =~ s/[\t\r\n]/ /g;
            push @rows, join("\t", 0, 'M', 0, $bar->IsEnabledTop($n) ? 1 : 0, 0, $label);
            $walk->($bar->GetMenu($n), 1);
        }
        %allowed = %current;
        my $snapshot = encode_utf8(join("\n", @rows)."\n");
        if ($snapshot ne $last) {
            if (open my $out, '>:raw', "$dir/menu.tmp") {
                print {$out} $snapshot;
                close $out;
                rename "$dir/menu.tmp", "$dir/menu.tsv";
                $last = $snapshot;
            }
        }
        for my $file (sort glob "$dir/cmd-*.ready") {
            open my $in, '<', $file or next;
            my $id = <$in>; close $in; unlink $file;
            next unless defined $id && $id =~ /^(-?\d+)\s*$/;
            $id = $1;
            my $item = $allowed{$id};
            next unless $item && $item->IsEnabled;
            if ($item->IsCheckable) {
                $item->Check($item->GetKind == Wx::wxITEM_RADIO() ? 1 : !$item->IsChecked);
            }
            my $event = Wx::CommandEvent->new(Wx::wxEVT_COMMAND_MENU_SELECTED(), $id);
            $event->SetInt($item->IsCheckable && $item->IsChecked ? 1 : 0);
            $event->SetEventObject($app->{main});
            $app->{main}->GetEventHandler->ProcessEvent($event);
        }
    });
    $timer->Start(250);
}
1;
