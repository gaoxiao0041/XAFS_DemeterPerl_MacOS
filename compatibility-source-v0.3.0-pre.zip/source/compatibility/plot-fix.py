"""Apply the local Athena WXT interaction patch to gnuplot 6.0.6."""
from pathlib import Path
import os, shutil, subprocess
root=Path.cwd()
prefix=Path(os.environ['MP'])
sources=list(prefix.glob('var/macports/build/gnuplot-*/work/gnuplot-6.0.6'))
if len(sources)!=1:
    raise SystemExit('Expected one retained gnuplot 6.0.6 build tree.')
build=sources[0]
for name in ('gnuplot-macos-mouse.patch', 'gnuplot-athena-menus.patch'):
    patch=root/name
    check=subprocess.run(['patch','--dry-run','--batch','--forward','-p1','-i',str(patch)],cwd=build)
    if check.returncode==0:
        subprocess.run(['patch','--batch','--forward','-p1','-i',str(patch)],cwd=build,check=True)
    else:
        subprocess.run(['patch','--dry-run','--batch','--reverse','-p1','-i',str(patch)],cwd=build,check=True)
version=build/'src/version.c'
s=version.read_text()
old='const char gnuplot_patchlevel[] = "6";'
new='const char gnuplot_patchlevel[] = "6-demeter-macos-v0.3.0-pre";'
if old in s:version.write_text(s.replace(old,new))
elif new not in s:raise SystemExit('Unexpected gnuplot version string.')
subprocess.run(['make','-j8'],cwd=build,check=True)
out=root/'plot-fix/bin'; out.mkdir(parents=True,exist_ok=True)
exe=out/'gnuplot'; shutil.copy2(build/'src/gnuplot',exe)
subprocess.run(['codesign','--force','--sign','-',str(exe)],check=True)
subprocess.run([str(exe),'--version'],check=True)
# Do not open GUI windows during installation. Confirm the WXT terminal exists.
result=subprocess.run([str(exe),'-e','set terminal'],capture_output=True,text=True,check=True)
if 'wxt' not in result.stdout+result.stderr:raise SystemExit('gnuplot was built without WXT.')
print('Athena private gnuplot ready. Interactive mouse acceptance remains a user GUI check.')
