"""Package only compatibility sources and explicit redistributable assets."""
from pathlib import Path
import hashlib, zipfile
here=Path(__file__).resolve().parent
out=here/'resources'; out.mkdir(exist_ok=True)
archive=out/'compatibility.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
    for p in sorted((here/'compatibility').rglob('*')):
        if p.is_file() and not p.is_symlink() and '__pycache__' not in p.parts and p.name!='.DS_Store':
            z.write(p,p.relative_to(here/'compatibility').as_posix())
(out/'compatibility.sha256').write_text(hashlib.sha256(archive.read_bytes()).hexdigest()+'\n')
print('Created compatibility payload and SHA-256.')
