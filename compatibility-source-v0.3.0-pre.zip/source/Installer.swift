import AppKit

final class InstallerDelegate: NSObject, NSApplicationDelegate {
    var window: NSWindow!
    var status: NSTextField!

    func applicationDidFinishLaunching(_ notification: Notification) {
        let app = NSApplication.shared
        app.setActivationPolicy(.regular)
        let mainMenu = NSMenu()
        let appItem = NSMenuItem()
        let appMenu = NSMenu()
        appMenu.addItem(withTitle: "退出安装器", action: #selector(NSApplication.terminate(_:)), keyEquivalent: "q")
        appItem.submenu = appMenu
        mainMenu.addItem(appItem)
        app.mainMenu = mainMenu

        window = NSWindow(
            contentRect: NSRect(x: 0, y: 0, width: 650, height: 455),
            styleMask: [.titled, .closable, .miniaturizable],
            backing: .buffered, defer: false)
        window.title = "Demeter · macOS 27.2 安装器"
        window.center()
        window.isReleasedWhenClosed = false

        let stack = NSStackView()
        stack.orientation = .vertical
        stack.alignment = .leading
        stack.spacing = 15
        stack.translatesAutoresizingMaskIntoConstraints = false
        window.contentView!.addSubview(stack)
        NSLayoutConstraint.activate([
            stack.leadingAnchor.constraint(equalTo: window.contentView!.leadingAnchor, constant: 30),
            stack.trailingAnchor.constraint(equalTo: window.contentView!.trailingAnchor, constant: -30),
            stack.topAnchor.constraint(equalTo: window.contentView!.topAnchor, constant: 28)
        ])

        let heading = NSTextField(labelWithString: "安装 Athena、Artemis、Hephaestus 和 Atoms")
        heading.font = .systemFont(ofSize: 20, weight: .semibold)
        stack.addArrangedSubview(heading)

        let details = NSTextField(wrappingLabelWithString:
            """
            适用系统  macOS 27.2.x · Apple Silicon
            准备要求  完整 Xcode、联网、至少 30 GiB 可用空间

            安装器会打开 Terminal，下载并编译依赖，应用兼容补丁，再创建四个应用图标。首次构建可能耗时数小时，Terminal 会持续显示进度。

            运行目录  ~/demeter-mac
            应用位置  ~/Applications
            安装日志  ~/demeter-mac/logs/install.log

            同名的其他软件会阻止自动安装。安装中断后可再次运行，保留已安装的依赖。此版本使用临时签名，尚未完成全新机器的端到端验收。
            """)
        details.font = .systemFont(ofSize: 13)
        details.textColor = .secondaryLabelColor
        details.preferredMaxLayoutWidth = 590
        stack.addArrangedSubview(details)

        let buttons = NSStackView()
        buttons.orientation = .horizontal
        buttons.spacing = 12
        let install = NSButton(title: "开始联网安装", target: self, action: #selector(startInstall))
        install.bezelStyle = .rounded
        install.keyEquivalent = "\r"
        buttons.addArrangedSubview(install)
        let guide = NSButton(title: "阅读安装教程", target: self, action: #selector(openGuide))
        guide.bezelStyle = .rounded
        buttons.addArrangedSubview(guide)
        stack.addArrangedSubview(buttons)

        status = NSTextField(wrappingLabelWithString: "点击后将在 Terminal 中显示安装进度。")
        status.font = .systemFont(ofSize: 12)
        status.textColor = .secondaryLabelColor
        status.preferredMaxLayoutWidth = 590
        stack.addArrangedSubview(status)

        window.makeKeyAndOrderFront(nil)
        app.activate(ignoringOtherApps: true)
    }

    func quoted(_ value: String) -> String {
        return "'" + value.replacingOccurrences(of: "'", with: "'\"'\"'") + "'"
    }

    @objc func startInstall() {
        do {
            guard let resources = Bundle.main.resourceURL else {
                throw NSError(domain: "DemeterInstaller", code: 1,
                              userInfo: [NSLocalizedDescriptionKey: "找不到安装资源。"])
            }
            let fm = FileManager.default
            let support = try fm.url(for: .applicationSupportDirectory, in: .userDomainMask,
                                     appropriateFor: nil, create: true)
            let run = support.appendingPathComponent("DemeterInstaller/run-" + UUID().uuidString)
            try fm.createDirectory(at: run, withIntermediateDirectories: true)
            for name in ["install.sh", "compatibility.zip", "compatibility.sha256"] {
                try fm.copyItem(at: resources.appendingPathComponent(name),
                                to: run.appendingPathComponent(name))
            }
            let command = run.appendingPathComponent("Install Demeter.command")
            let script = "#!/bin/bash\n" +
                "/bin/bash " + quoted(run.appendingPathComponent("install.sh").path) + " " + quoted(run.path) + "\n" +
                "result=$?\nprintf '\\n终端任务结束，退出码 %s。日志位于 ~/demeter-mac/logs/install.log\\n' \"$result\"\n" +
                "printf '按回车键关闭本窗口。'\nread -r reply\nexit \"$result\"\n"
            try script.write(to: command, atomically: true, encoding: .utf8)
            try fm.setAttributes([.posixPermissions: 0o755], ofItemAtPath: command.path)
            if NSWorkspace.shared.open(command) {
                status.stringValue = "已请求在 Terminal 启动安装。请在 Terminal 查看输出和最终结果。"
            } else {
                status.stringValue = "无法自动打开 Terminal。安装脚本位于 " + run.path
            }
        } catch {
            status.stringValue = "启动失败：" + error.localizedDescription
        }
    }

    @objc func openGuide() {
        guard let url = Bundle.main.url(forResource: "Guide", withExtension: "html") else {
            status.stringValue = "请打开磁盘映像根目录的安装教程。"
            return
        }
        NSWorkspace.shared.open(url)
    }

    func applicationShouldTerminateAfterLastWindowClosed(_ sender: NSApplication) -> Bool {
        return true
    }
}

let application = NSApplication.shared
let delegate = InstallerDelegate()
application.delegate = delegate
application.run()
