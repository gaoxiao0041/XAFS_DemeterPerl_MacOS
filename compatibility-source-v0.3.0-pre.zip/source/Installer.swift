import AppKit

final class InstallerDelegate: NSObject, NSApplicationDelegate {
    var window: NSWindow!
    var status: NSTextField!

    func applicationDidFinishLaunching(_ notification: Notification) {
        let app = NSApplication.shared
        app.setActivationPolicy(.regular)
        let mainMenu = NSMenu()
        let appItem = NSMenuItem()
        let appMenu = NSMenu()
        appMenu.addItem(withTitle: "Quit Installer", action: #selector(NSApplication.terminate(_:)), keyEquivalent: "q")
        appItem.submenu = appMenu
        mainMenu.addItem(appItem)
        app.mainMenu = mainMenu

        window = NSWindow(
            contentRect: NSRect(x: 0, y: 0, width: 650, height: 455),
            styleMask: [.titled, .closable, .miniaturizable],
            backing: .buffered, defer: false)
        window.title = "Demeter macOS 27.2 Installer"
        window.center()
        window.isReleasedWhenClosed = false

        let stack = NSStackView()
        stack.orientation = .vertical
        stack.alignment = .leading
        stack.spacing = 15
        stack.translatesAutoresizingMaskIntoConstraints = false
        window.contentView!.addSubview(stack)
        NSLayoutConstraint.activate([
            stack.leadingAnchor.constraint(equalTo: window.contentView!.leadingAnchor, constant: 30),
            stack.trailingAnchor.constraint(equalTo: window.contentView!.trailingAnchor, constant: -30),
            stack.topAnchor.constraint(equalTo: window.contentView!.topAnchor, constant: 28)
        ])

        let heading = NSTextField(labelWithString: "Install Athena, Artemis, Hephaestus and Atoms")
        heading.font = .systemFont(ofSize: 20, weight: .semibold)
        stack.addArrangedSubview(heading)

        let details = NSTextField(wrappingLabelWithString:
            """
            macOS 27.2.x / Apple Silicon
            Full Xcode, internet and at least 30 GiB free space required

            Downloads and compiles dependencies in Terminal, applies compatibility patches and creates four app launchers. The first build may take hours.

            Runtime: ~/demeter-mac
            Apps: ~/Applications
            Log: ~/demeter-mac/logs/install.log

            Conflicting installations are preserved. Normal retries reuse completed dependencies. Ad hoc signature; not notarized. Clean-machine installation and recent mouse/menu GUI acceptance remain unverified.
            """)
        details.font = .systemFont(ofSize: 13)
        details.textColor = .secondaryLabelColor
        details.preferredMaxLayoutWidth = 590
        stack.addArrangedSubview(details)

        let buttons = NSStackView()
        buttons.orientation = .horizontal
        buttons.spacing = 12
        let install = NSButton(title: "Start Online Installation", target: self, action: #selector(startInstall))
        install.bezelStyle = .rounded
        install.keyEquivalent = "\r"
        buttons.addArrangedSubview(install)
        let guide = NSButton(title: "Read Guide", target: self, action: #selector(openGuide))
        guide.bezelStyle = .rounded
        buttons.addArrangedSubview(guide)
        stack.addArrangedSubview(buttons)

        status = NSTextField(wrappingLabelWithString: "Installation progress will appear in Terminal.")
        status.font = .systemFont(ofSize: 12)
        status.textColor = .secondaryLabelColor
        status.preferredMaxLayoutWidth = 590
        stack.addArrangedSubview(status)

        window.makeKeyAndOrderFront(nil)
        app.activate(ignoringOtherApps: true)
    }

    func quoted(_ value: String) -> String {
        return "'" + value.replacingOccurrences(of: "'", with: "'\"'\"'") + "'"
    }

    @objc func startInstall() {
        do {
            guard let resources = Bundle.main.resourceURL else {
                throw NSError(domain: "DemeterInstaller", code: 1,
                              userInfo: [NSLocalizedDescriptionKey: "Installer resources were not found."])
            }
            let fm = FileManager.default
            let support = try fm.url(for: .applicationSupportDirectory, in: .userDomainMask,
                                     appropriateFor: nil, create: true)
            let run = support.appendingPathComponent("DemeterInstaller/run-" + UUID().uuidString)
            try fm.createDirectory(at: run, withIntermediateDirectories: true)
            for name in ["install.sh", "compatibility.zip", "compatibility.sha256"] {
                try fm.copyItem(at: resources.appendingPathComponent(name),
                                to: run.appendingPathComponent(name))
            }
            let command = run.appendingPathComponent("Install Demeter.command")
            let script = "#!/bin/bash\n" +
                "/bin/bash " + quoted(run.appendingPathComponent("install.sh").path) + " " + quoted(run.path) + "\n" +
                "result=$?\nprintf '\\nInstaller exited with code %s. Log: ~/demeter-mac/logs/install.log\\n' \"$result\"\n" +
                "printf 'Press Return to close this window.'\nread -r reply\nexit \"$result\"\n"
            try script.write(to: command, atomically: true, encoding: .utf8)
            try fm.setAttributes([.posixPermissions: 0o755], ofItemAtPath: command.path)
            if NSWorkspace.shared.open(command) {
                status.stringValue = "Installation requested in Terminal. Check its output for the final result."
            } else {
                status.stringValue = "Could not open Terminal. Installer scripts: " + run.path
            }
        } catch {
            status.stringValue = "Launch failed: " + error.localizedDescription
        }
    }

    @objc func openGuide() {
        guard let url = Bundle.main.url(forResource: "Guide", withExtension: "html") else {
            status.stringValue = "Open the guide in the disk image."
            return
        }
        NSWorkspace.shared.open(url)
    }

    func applicationShouldTerminateAfterLastWindowClosed(_ sender: NSApplication) -> Bool {
        return true
    }
}

let application = NSApplication.shared
let delegate = InstallerDelegate()
application.delegate = delegate
application.run()
