#!/bin/bash
set -Eeuo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
RELEASE="$(dirname "$HERE")"
BUILD="$RELEASE/build"
VOLUME="$BUILD/volume"
APP="$VOLUME/Demeter Installer.app"
CONTENTS="$APP/Contents"
DMG="$RELEASE/Demeter-macOS-27.2-online-arm64-v0.3.0-pre.dmg"
if [ -e "$DMG" ]; then printf 'Output already exists: %s\n' "$DMG" >&2; exit 1; fi
mkdir -p "$CONTENTS/MacOS" "$CONTENTS/Resources" "$BUILD/swift-cache"
python3 "$HERE/build-payload.py"
cp "$HERE/install.sh" "$CONTENTS/Resources/install.sh"
cp "$HERE/resources/compatibility.zip" "$HERE/resources/compatibility.sha256" "$CONTENTS/Resources/"
cp "$HERE/compatibility/icons/Athena.icns" "$CONTENTS/Resources/App.icns"
python3 - "$RELEASE" "$CONTENTS" <<'PY'
from pathlib import Path
import sys,plistlib,html
release=Path(sys.argv[1]); contents=Path(sys.argv[2])
with (contents/'Info.plist').open('wb') as f:
    plistlib.dump(dict(CFBundleName='Demeter Installer',CFBundleDisplayName='Demeter Installer',CFBundleExecutable='DemeterInstaller',CFBundleIdentifier='local.demeter.installer',CFBundlePackageType='APPL',CFBundleIconFile='App.icns',CFBundleShortVersionString='0.3.0',CFBundleVersion='3',NSHighResolutionCapable=True),f)
body=html.escape((release/'README.md').read_text())
(contents/'Resources/Guide.html').write_text('<!doctype html><html lang="zh-CN"><meta charset="utf-8"><title>Demeter 安装说明</title><style>body{max-width:1000px;margin:40px auto;padding:0 24px;background:#fafafa;color:#202124;font:17px/1.7 system-ui}pre{white-space:pre-wrap;overflow-wrap:anywhere;font:inherit}</style><body><pre>'+body+'</pre></body></html>')
PY
xcrun swiftc -module-cache-path "$BUILD/swift-cache" -framework AppKit "$HERE/Installer.swift" -o "$CONTENTS/MacOS/DemeterInstaller"
codesign --force --sign - "$APP"
codesign --verify --strict "$APP"
cp "$RELEASE/README.md" "$VOLUME/先读我.md"
cp "$RELEASE/README.md" "$RELEASE/RELEASE_NOTES.md" "$VOLUME/"
cp "$RELEASE/THIRD_PARTY_NOTICES.md" "$RELEASE/LICENSE" "$RELEASE/NOTICE.md" "$RELEASE/INSTALL.zh-CN.md" "$VOLUME/"
for extra in "$RELEASE/Demeter-macOS-27.2-视频讲解.pptx" "$RELEASE/视频讲稿.md"; do
  if [ -f "$extra" ]; then cp "$extra" "$VOLUME/"; fi
done
mkdir -p "$VOLUME/licenses" "$VOLUME/source"
cp -R "$RELEASE/licenses/." "$VOLUME/licenses/"
cp "$HERE/install.sh" "$HERE/Installer.swift" "$HERE/build-payload.py" "$HERE/build-dmg.sh" "$VOLUME/source/"
cp -R "$HERE/compatibility" "$VOLUME/source/"
# Source archive in the volume retains transparent patches, not a user runtime.
hdiutil makehybrid -hfs -hfs-volume-name 'Demeter macOS 27.2 v0.3.0-pre' -o "$BUILD/source-image.cdr" "$VOLUME"
SOURCE="$BUILD/source-image.cdr.dmg"
[ -f "$SOURCE" ] || SOURCE="$BUILD/source-image.cdr"
hdiutil convert "$SOURCE" -format UDZO -o "$DMG"
hdiutil verify "$DMG"
printf 'Created %s\n' "$DMG"
