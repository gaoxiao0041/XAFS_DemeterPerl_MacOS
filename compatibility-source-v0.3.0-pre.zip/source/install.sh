#!/bin/bash
set -Eeuo pipefail
export PATH="/usr/bin:/bin:/usr/sbin:/sbin"
export LC_ALL=en_US.UTF-8
PAYLOAD="${1:?Missing installer resources}"
ROOT="$HOME/demeter-mac"
case "$ROOT" in
  *[!a-zA-Z0-9_./-]*) printf "安装路径必须为不含空格的 ASCII 路径。当前 HOME 不符合要求。\n" >&2; exit 1 ;;
esac
MP="$ROOT/prefix"
export ROOT MP
EXPECTED_PORTS=98f7ca3d00a5633a3231b253e8eac2272d2e033d
fail() { printf '\n安装停止: %s\n' "$*" >&2; exit 1; }

case "$(/usr/bin/sw_vers -productVersion)" in
  27.2|27.2.*) ;;
  *) fail "此安装器支持 macOS 27.2。请使用通用教程核对其他系统版本。" ;;
esac
[ "$(uname -m)" = arm64 ] || fail "此安装器针对 Apple Silicon arm64。"
developer=$(/usr/bin/xcode-select -p) || fail "请先安装 Xcode 和 Command Line Tools。"
case "$developer" in
  *.app/Contents/Developer) ;;
  *) fail "请选择完整 Xcode: sudo xcode-select -s /Applications/Xcode.app/Contents/Developer" ;;
esac
/usr/bin/xcodebuild -version || fail "请先打开 Xcode，完成许可与首次组件安装。"
[ -x /usr/bin/python3 ] || fail "完整 Xcode 需要提供 /usr/bin/python3。"
available_kb=$(/bin/df -Pk "$HOME" | /usr/bin/awk 'END {print $4}')
[ "$available_kb" -ge 31457280 ] || fail "请至少预留 30 GiB 可用空间。依赖构建可能需要更多。"
if [ "${2:-}" = "--check-only" ]; then
  printf '预检查通过：系统、架构、Xcode、可用空间和路径。未下载或安装。\n'
  exit 0
fi
if [ -d "$ROOT" ] && [ ! -f "$ROOT/.demeter-installer" ]; then
  fail "$ROOT 已存在且并非此安装器创建。请保留原目录，手动按教程安装。"
fi
/bin/mkdir -p "$ROOT/logs"
printf '%s\n' 'demeter-macos27.2-v3' > "$ROOT/.demeter-installer"
lock="$ROOT/.install-lock"
if ! /bin/mkdir "$lock" 2>/dev/null; then
  fail "已有安装锁。确认没有安装进程后，可删除 $lock 再重试。"
fi
trap '/bin/rmdir "$lock" 2>/dev/null || true' EXIT
exec > >(/usr/bin/tee -a "$ROOT/logs/install.log") 2>&1
trap 'rc=$?; printf "\n安装失败，退出码 %s，步骤 %s\n日志 %s\n" "$rc" "$STEP" "$ROOT/logs/install.log"; exit "$rc"' ERR
STEP=preflight
printf '\nDemeter macOS 27.2 安装器\n日期 %s\n目录 %s\n' "$(date)" "$ROOT"
printf '首次构建可能耗时数小时。可保留 Terminal 运行并随时查看日志。\n'
for name in Athena Artemis Hephaestus 'Stand-alone Atoms'; do
  existing="$HOME/Applications/$name.app"
  if [ -e "$existing" ]; then
    identifier=$(/usr/libexec/PlistBuddy -c 'Print CFBundleIdentifier' "$existing/Contents/Info.plist" 2>/dev/null || true)
    case "$identifier" in
      local.demeter.guide.*) ;;
      *) fail "$existing 已存在。为避免覆盖，请先另行备份或手动安装。" ;;
    esac
  fi
done
cd "$ROOT"
STEP=extract
actual=$(/usr/bin/shasum -a 256 "$PAYLOAD/compatibility.zip" | /usr/bin/awk '{print $1}')
expected=$(/bin/cat "$PAYLOAD/compatibility.sha256")
[ "$actual" = "$expected" ] || fail "内置兼容包校验失败。"
# State and logs are deliberately outside the archive.
/usr/bin/unzip -qo "$PAYLOAD/compatibility.zip" -d "$ROOT"
cat > "$ROOT/demeter-env.sh" <<'EOF'
export ROOT="$HOME/demeter-mac"
case "$ROOT" in
  *[!a-zA-Z0-9_./-]*) printf "安装路径必须为不含空格的 ASCII 路径。当前 HOME 不符合要求。\n" >&2; exit 1 ;;
esac
export MP="$ROOT/prefix"
export PATH="$MP/bin:$MP/sbin:$PATH"
export PERL5LIB="$ROOT/overlay:$ROOT/extra/lib/perl5"
EOF
download_checked() {
  url="$1"; dest="$2"; wanted="$3"
  if [ -f "$dest" ]; then
    actual=$(/usr/bin/shasum -a 256 "$dest" | /usr/bin/awk '{print $1}')
    [ "$actual" = "$wanted" ] && return 0
  fi
  /usr/bin/curl --fail --location --retry 3 --connect-timeout 30 \
    "$url" -o "$dest.partial"
  actual=$(/usr/bin/shasum -a 256 "$dest.partial" | /usr/bin/awk '{print $1}')
  [ "$actual" = "$wanted" ] || fail "下载校验失败: $dest"
  /bin/mv "$dest.partial" "$dest"
}
STEP=macports
if [ ! -x "$MP/bin/port" ]; then
  download_checked \
    https://distfiles.macports.org/MacPorts/MacPorts-2.12.7.tar.bz2 \
    "$ROOT/MacPorts-2.12.7.tar.bz2" 6a3730de846bb78e3fb4ced2ed8d13f777e6aca2ab2f59cade9ca0d549ccc4ba
  /usr/bin/tar -xjf MacPorts-2.12.7.tar.bz2
  (
    cd MacPorts-2.12.7
    ./configure --prefix="$MP" \
      --with-applications-dir="$MP/Applications" \
      --with-no-root-privileges --without-startupitems \
      --with-unsupported-prefix
    /usr/bin/make -j8
    /usr/bin/make install
  )
fi
"$MP/bin/port" version | /usr/bin/grep -q '2.12.7' || fail "前缀中的 MacPorts 版本不匹配。"
export PATH="$MP/bin:/usr/bin:/bin:/usr/sbin:/sbin"
STEP=ports
if [ ! -d ports/.git ]; then
  [ ! -e ports ] || fail "ports 目录存在，但不是 Git 源码树。"
  /usr/bin/git init ports
  /usr/bin/git -C ports remote add origin https://github.com/macports/macports-ports.git
  /usr/bin/git -C ports fetch --depth 1 origin "$EXPECTED_PORTS"
  /usr/bin/git -C ports checkout --detach FETCH_HEAD
fi
[ "$(/usr/bin/git -C ports rev-parse HEAD)" = "$EXPECTED_PORTS" ] || fail "ports 快照版本不匹配。"
for patch_file in "$ROOT"/ports-patches/*.patch; do
  if /usr/bin/git -C ports apply --check "$patch_file" 2>/dev/null; then
    /usr/bin/git -C ports apply "$patch_file"
  elif /usr/bin/git -C ports apply --reverse --check "$patch_file" 2>/dev/null; then
    printf '已应用 %s\n' "$patch_file"
  else
    fail "补丁不匹配: $patch_file"
  fi
done
printf 'file://%s/ports [default]\n' "$ROOT" > "$MP/etc/macports/sources.conf"
for option in 'portautoclean no'; do
  /usr/bin/grep -qxF "$option" "$MP/etc/macports/macports.conf" ||
    printf '\n%s\n' "$option" >> "$MP/etc/macports/macports.conf"
done
for option in -qt6 -aquaterm; do
  /usr/bin/grep -qxF -- "$option" "$MP/etc/macports/variants.conf" ||
    printf '\n%s\n' "$option" >> "$MP/etc/macports/variants.conf"
done
/usr/bin/python3 - <<'PYCODE'
import os
from pathlib import Path
p = Path(os.environ["MP"]) / "libexec/macports/lib/port1.0/portconfigure.tcl"
s = p.read_text()
marker = "        parse_environment configure\n"
line = ("        append_to_environment_value configure "
        "lt_cv_sys_max_cmd_len 262144\n")
if line not in s:
    if marker not in s:
        raise SystemExit("Unexpected MacPorts source")
    p.with_suffix(".tcl.bak").write_text(s)
    p.write_text(s.replace(marker, marker + line, 1))
PYCODE
(cd ports && "$MP/bin/portindex")
STEP=dependencies
printf '\n正在构建 wxWidgets。首次运行可能较慢。\n'
"$MP/bin/port" -s install wxWidgets-3.0
printf '\n正在安装 Demeter 和 X11 依赖。\n'
"$MP/bin/port" install demeter xorg-server
export PERL5LIB="$ROOT/overlay:$ROOT/extra/lib/perl5"
STEP=pdl-filter
if ! "$MP/bin/perl5.34" -MPDL::Filter -e 1 >/dev/null 2>&1; then
  download_checked \
    https://cpan.metacpan.org/authors/id/E/ET/ETJ/PDL-Filter-2.097.tar.gz \
    "$ROOT/PDL-Filter-2.097.tar.gz" 4af14b49acbe2c0ad9e15c59c12105fcf2cb325abf7c4aa0e1f53f0525eb2ab7
  /usr/bin/tar -xzf PDL-Filter-2.097.tar.gz
  (
    cd PDL-Filter-2.097
    "$MP/bin/perl5.34" Makefile.PL INSTALL_BASE="$ROOT/extra"
    /usr/bin/make
    /usr/bin/make test
    /usr/bin/make install
  )
fi
STEP=wx-fix
/usr/bin/python3 wx-fix.py
DYLD_LIBRARY_PATH="$ROOT/wx-fixed" "$MP/bin/perl5.34" -MWx -e 'print "Wx OK\n"'
"$MP/bin/perl5.34" -MIfeffit -MPDL::Filter -e 'print "Ifeffit / PDL OK\n"'
STEP=plot-fix
"$MP/bin/port" -s build gnuplot +wxwidgets +pangocairo +x11 -qt5 -qt6 -aquaterm
/usr/bin/python3 plot-fix.py
STEP=applications
core=$("$MP/bin/perl5.34" -MConfig -e 'print "$Config{archlib}/CORE"')
/usr/bin/xcrun clang -bundle -undefined dynamic_lookup -framework AppKit \
  -I"$core" athena-appearance.m -o overlay/Athena/Appearance.bundle
vendor=$("$MP/bin/perl5.34" -MConfig -e 'print $Config{vendorarch}')
/bin/ln -sfn "$vendor/Demeter/UI/Athena/icons" overlay/Demeter/UI/Athena/icons
/usr/bin/python3 make-apps.py
/bin/mkdir -p "$HOME/Applications" "$ROOT/backups"
stamp=$(/bin/date +%Y%m%d-%H%M%S)
for app in "$ROOT"/apps/*.app; do
  name="${app##*/}"
  dest="$HOME/Applications/$name"
  staged="$HOME/Applications/.$name.installing"
  [ ! -e "$staged" ] || fail "暂存目录存在: $staged"
  /usr/bin/ditto "$app" "$staged"
  /usr/bin/codesign --verify --strict "$staged"
  backup="$ROOT/backups/$stamp-$name"
  if [ -e "$dest" ]; then /bin/mv "$dest" "$backup"; fi
  if ! /bin/mv "$staged" "$dest"; then
    if [ -e "$backup" ]; then /bin/mv "$backup" "$dest"; fi
    fail "无法安装 $name，原版本已尝试恢复。"
  fi
done
STEP=complete
"$MP/bin/port" installed > "$ROOT/installed-ports.txt"
printf '\n安装步骤完成。\n应用位置 %s\n日志 %s\n' \
  "$HOME/Applications" "$ROOT/logs/install.log"
printf '请逐一打开四个程序，按教程完成计算与绘图验收。\n'
printf '更新后若已有旧窗口，请先 Command-Q 完全退出。\n'
/usr/bin/open "$HOME/Applications" || true
